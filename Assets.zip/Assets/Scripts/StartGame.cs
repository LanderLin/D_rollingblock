﻿using UnityEngine;
using UnityEngine.SceneManagement;

public class StartGame : MonoBehaviour
{
    public void startGame() {
        this.transform.GetComponent<AudioSource>().Play();
        Invoke("toManual", 0.7f);
       
    }
    public void toManual() {
        SceneManager.LoadSceneAsync(1);
    }
}
