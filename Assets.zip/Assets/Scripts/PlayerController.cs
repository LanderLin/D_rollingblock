﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Assets.Scripts;

public class PlayerController : MonoBehaviour
{

    private Transform b_Transform;

    private BoxCollider boxCollider;

    private GameObject gameManager;
    private RollingContorller rollingController; 
    private RollStruct message;


    public int b_State=0;

    // Start is called before the first frame update
    void Start()
    {
        b_Transform = gameObject.GetComponent<Transform>();
        boxCollider = gameObject.GetComponent<BoxCollider>();
        gameManager = GameObject.Find("GameManager");
        rollingController = this.gameObject.GetComponent<RollingContorller>();
    }

    // Update is called once per frame
    //b_State 0:  XX
    //                   XX
    //
    //              1:  XX
    //
    //              2:  X
    //                   X
    void Update()
    {
        
        
        if (Input.GetKeyDown(KeyCode.UpArrow) ) {
            if (b_State==0 ) {
                boxCollider.enabled = false;
                Vector3 rotatePoint = new Vector3(b_Transform.position.x, b_Transform.position.y - 0.5f, b_Transform.position.z + 1);
                if (Physics.Linecast(rotatePoint, new Vector3(rotatePoint.x+0.5f, rotatePoint.y, rotatePoint.z+0.5f)) && Physics.Linecast(rotatePoint, new Vector3(rotatePoint.x - 0.5f, rotatePoint.y, rotatePoint.z + 0.5f))) {
                   // b_Transform.RotateAround(rotatePoint, new Vector3(1, 0, 0),90);
                    message.point = rotatePoint;
                    message.axis = new Vector3(1, 0, 0);
                    message.b_State = 1;
                    rollingController.SendMessage("receiveMsg", message);
                    b_State = 1;
                    boxCollider.enabled = true;
                    
                }
            } else if (b_State == 1) {
                boxCollider.enabled = false;
                Vector3 rotatePoint = new Vector3(b_Transform.position.x, b_Transform.position.y - 1, b_Transform.position.z + 0.5f);
                if (Physics.Linecast(rotatePoint, new Vector3(rotatePoint.x - 0.5f, rotatePoint.y, rotatePoint.z + 0.5f)) 
                     && Physics.Linecast(rotatePoint, new Vector3(rotatePoint.x + 0.5f, rotatePoint.y, rotatePoint.z + 0.5f))
                     && Physics.Linecast(new Vector3(rotatePoint.x - 0.5f,rotatePoint.y,rotatePoint.z+1), new Vector3(rotatePoint.x - 0.5f, rotatePoint.y, rotatePoint.z + 1.5f))
                     && Physics.Linecast(new Vector3(rotatePoint.x + 0.5f, rotatePoint.y, rotatePoint.z + 1), new Vector3(rotatePoint.x + 0.5f, rotatePoint.y, rotatePoint.z + 1.5f))) {
                    //b_Transform.RotateAround(rotatePoint, new Vector3(1, 0, 0), 90);
                    message.point = rotatePoint;
                    message.axis = new Vector3(1, 0, 0);
                    message.b_State = 0;
                    rollingController.SendMessage("receiveMsg", message);
                    b_State = 0;
                    boxCollider.enabled = true;
                  
                }
            } else {
                boxCollider.enabled = false;
                Vector3 rotatePoint = new Vector3(b_Transform.position.x, b_Transform.position.y - 1, b_Transform.position.z + 1);
                if (Physics.Linecast(rotatePoint, new Vector3(rotatePoint.x, rotatePoint.y, rotatePoint.z + 0.5f)) && Physics.Linecast(new Vector3(rotatePoint.x, rotatePoint.y, rotatePoint.z +1), new Vector3(rotatePoint.x, rotatePoint.y, rotatePoint.z + 1.5f))) {
                    //b_Transform.RotateAround(rotatePoint, new Vector3(1, 0, 0), 90);
                    message.point = rotatePoint;
                    message.axis = new Vector3(1, 0, 0);
                    message.b_State = 2;
                    rollingController.SendMessage("receiveMsg", message);
                    b_State = 2;
                    boxCollider.enabled = true;
                }
            }
        }

        if (Input.GetKeyDown(KeyCode.DownArrow) ) {
            if (b_State == 0) {
                boxCollider.enabled = false;
                Vector3 rotatePoint = new Vector3(b_Transform.position.x, b_Transform.position.y - 0.5f, b_Transform.position.z - 1);
                if (Physics.Linecast(rotatePoint, new Vector3(rotatePoint.x - 0.5f, rotatePoint.y, rotatePoint.z - 0.5f)) && Physics.Linecast(rotatePoint, new Vector3(rotatePoint.x + 0.5f, rotatePoint.y, rotatePoint.z - 0.5f))) {
                    //b_Transform.RotateAround(rotatePoint, new Vector3(-1, 0, 0), 90);
                    message.point = rotatePoint;
                    message.axis = new Vector3(-1, 0, 0);
                    message.b_State = 1;
                    rollingController.SendMessage("receiveMsg", message);
                    b_State = 1;
                    boxCollider.enabled = true;
                    
                }

            } else if (b_State == 1) {
                boxCollider.enabled = false;
                Vector3 rotatePoint = new Vector3(b_Transform.position.x, b_Transform.position.y - 1, b_Transform.position.z - 0.5f);
                if (Physics.Linecast(rotatePoint, new Vector3(rotatePoint.x - 0.5f, rotatePoint.y, rotatePoint.z - 0.5f))
                     && Physics.Linecast(rotatePoint, new Vector3(rotatePoint.x + 0.5f, rotatePoint.y, rotatePoint.z - 0.5f))
                     && Physics.Linecast(new Vector3(rotatePoint.x - 0.5f, rotatePoint.y, rotatePoint.z - 1), new Vector3(rotatePoint.x - 0.5f, rotatePoint.y, rotatePoint.z - 1.5f))
                     && Physics.Linecast(new Vector3(rotatePoint.x + 0.5f, rotatePoint.y, rotatePoint.z - 1), new Vector3(rotatePoint.x + 0.5f, rotatePoint.y, rotatePoint.z - 1.5f))) {
                    //b_Transform.RotateAround(rotatePoint, new Vector3(-1, 0, 0), 90);
                    message.point = rotatePoint;
                    message.axis = new Vector3(-1, 0, 0);
                    message.b_State = 0;
                    rollingController.SendMessage("receiveMsg", message);
                    b_State = 0;
                    boxCollider.enabled = true;
                    

                }

            } else {
                boxCollider.enabled = false;
                Vector3 rotatePoint = new Vector3(b_Transform.position.x, b_Transform.position.y - 1, b_Transform.position.z - 1);
                if (Physics.Linecast(rotatePoint, new Vector3(rotatePoint.x, rotatePoint.y, rotatePoint.z - 0.5f)) && Physics.Linecast(new Vector3(rotatePoint.x, rotatePoint.y, rotatePoint.z - 1), new Vector3(rotatePoint.x, rotatePoint.y, rotatePoint.z - 1.5f))) {
                    //b_Transform.RotateAround(rotatePoint, new Vector3(-1, 0, 0), 90);
                    message.point = rotatePoint;
                    message.axis = new Vector3(-1, 0, 0);
                    message.b_State = 2;
                    rollingController.SendMessage("receiveMsg", message);
                    b_State = 2;
                    boxCollider.enabled = true;
                    
                }

            }
        }

        if (Input.GetKeyDown(KeyCode.LeftArrow)) {
            boxCollider.enabled = false;
            if (b_State == 0) {
                Vector3 rotatePoint = new Vector3(b_Transform.position.x - 1, b_Transform.position.y - 0.5f, b_Transform.position.z);
                if (Physics.Linecast(rotatePoint, new Vector3(rotatePoint.x - 0.5f, rotatePoint.y, rotatePoint.z - 0.5f)) && Physics.Linecast(rotatePoint, new Vector3(rotatePoint.x - 0.5f, rotatePoint.y, rotatePoint.z + 0.5f))) {
                    //b_Transform.RotateAround(rotatePoint, new Vector3(0, 0, 1), 90);
                    message.point = rotatePoint;
                    message.axis = new Vector3(0, 0, 1);
                    message.b_State = 2;
                    rollingController.SendMessage("receiveMsg", message);
                    b_State = 2;
                    boxCollider.enabled = true;
                    
                }
            }else if (b_State == 1) {
                Vector3 rotatePoint = new Vector3(b_Transform.position.x - 1, b_Transform.position.y - 1, b_Transform.position.z);
                if (Physics.Linecast(rotatePoint,new Vector3(rotatePoint.x-0.5f,rotatePoint.y,rotatePoint.z))&&Physics.Linecast(new Vector3(rotatePoint.x-1,rotatePoint.y,rotatePoint.z),new Vector3(rotatePoint.x-1.5f,rotatePoint.y,rotatePoint.z))) {
                    //b_Transform.RotateAround(rotatePoint, new Vector3(0, 0, 1), 90);
                    message.point = rotatePoint;
                    message.axis = new Vector3(0, 0, 1);
                    message.b_State = 1;
                    rollingController.SendMessage("receiveMsg", message);
                    b_State = 1;
                    boxCollider.enabled = true;
                    
                }  
            } else {
                Vector3 rotatePoint = new Vector3(b_Transform.position.x-0.5f, b_Transform.position.y - 1, b_Transform.position.z);
                if (Physics.Linecast(rotatePoint, new Vector3(rotatePoint.x - 0.5f, rotatePoint.y, rotatePoint.z - 0.5f))
                     && Physics.Linecast(rotatePoint, new Vector3(rotatePoint.x - 0.5f, rotatePoint.y, rotatePoint.z + 0.5f))
                     && Physics.Linecast(new Vector3(rotatePoint.x - 1, rotatePoint.y, rotatePoint.z), new Vector3(rotatePoint.x - 1.5f, rotatePoint.y, rotatePoint.z - 0.5f))
                     && Physics.Linecast(new Vector3(rotatePoint.x - 1, rotatePoint.y, rotatePoint.z), new Vector3(rotatePoint.x - 1.5f, rotatePoint.y, rotatePoint.z + 0.5f))) {
                    //b_Transform.RotateAround(rotatePoint, new Vector3(0, 0, 1), 90);
                    message.point = rotatePoint;
                    message.axis = new Vector3(0, 0, 1);
                    message.b_State = 0;
                    rollingController.SendMessage("receiveMsg", message);
                    b_State = 0;
                    boxCollider.enabled = true;
                
                }
            }

        }

        if (Input.GetKeyDown(KeyCode.RightArrow)) {
            boxCollider.enabled = false;
            if (b_State == 0) {                
                Vector3 rotatePoint = new Vector3(b_Transform.position.x + 1, b_Transform.position.y - 0.5f, b_Transform.position.z);
                if (Physics.Linecast(rotatePoint,new Vector3(rotatePoint.x+0.5f,rotatePoint.y,rotatePoint.z+0.5f)) && Physics.Linecast(rotatePoint, new Vector3(rotatePoint.x+0.5f, rotatePoint.y, rotatePoint.z - 0.5f))) {
                    //b_Transform.RotateAround(rotatePoint, new Vector3(0, 0, -1), 90);
                    message.point = rotatePoint;
                    message.axis = new Vector3(0, 0, -1);
                    message.b_State = 2;
                    rollingController.SendMessage("receiveMsg", message);
                    b_State = 2;
                    boxCollider.enabled = true;
                    
                }
            }else if (b_State == 1) {
                Vector3 rotatePoint = new Vector3(b_Transform.position.x + 1, b_Transform.position.y - 1, b_Transform.position.z);
                if (Physics.Linecast(rotatePoint, new Vector3(rotatePoint.x+0.5f, rotatePoint.y, rotatePoint.z)) && Physics.Linecast(new Vector3(rotatePoint.x+1, rotatePoint.y, rotatePoint.z), new Vector3(rotatePoint.x+1.5f, rotatePoint.y, rotatePoint.z))) {
                    //b_Transform.RotateAround(rotatePoint, new Vector3(0, 0, -1), 90);
                    message.point = rotatePoint;
                    message.axis = new Vector3(0, 0, -1);
                    message.b_State = 1;
                    rollingController.SendMessage("receiveMsg", message);
                    b_State = 1;
                    boxCollider.enabled = true;
                    
                }                
            } else {
                Vector3 rotatePoint = new Vector3(b_Transform.position.x + 0.5f, b_Transform.position.y - 1, b_Transform.position.z);
                if (Physics.Linecast(rotatePoint, new Vector3(rotatePoint.x + 0.5f, rotatePoint.y, rotatePoint.z - 0.5f))
                     && Physics.Linecast(rotatePoint, new Vector3(rotatePoint.x + 0.5f, rotatePoint.y, rotatePoint.z + 0.5f))
                     && Physics.Linecast(new Vector3(rotatePoint.x + 1, rotatePoint.y, rotatePoint.z), new Vector3(rotatePoint.x + 1.5f, rotatePoint.y, rotatePoint.z - 0.5f))
                     && Physics.Linecast(new Vector3(rotatePoint.x + 1, rotatePoint.y, rotatePoint.z), new Vector3(rotatePoint.x + 1.5f, rotatePoint.y, rotatePoint.z + 0.5f))) {
                    //b_Transform.RotateAround(rotatePoint, new Vector3(0, 0, -1), 90);
                    message.point = rotatePoint;
                    message.axis = new Vector3(0, 0, -1);
                    message.b_State = 0;
                    rollingController.SendMessage("receiveMsg", message);
                    b_State = 0;
                    boxCollider.enabled = true;
                    
                }

            }

        }

    }
}
