﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class LevelSelect : MonoBehaviour {

    private GameObject locktext;
    private GameObject unlocktext;

    public void Start() {
        unlocktext = transform.GetChild(0).gameObject;
        locktext = transform.GetChild(1).gameObject;
        unlocktext.GetComponent<Button>().onClick.AddListener(Selected);
        //如果是第一关直接解锁
        if (transform.parent.GetChild(0).name == gameObject.name) {
            unlocktext.SetActive(true);
            locktext.SetActive(false);
        } else {
            int beforeLevel = int.Parse(gameObject.name) - 1;
            
            if (PlayerPrefs.GetInt("level" + beforeLevel.ToString(), 0) > 0) {
                unlocktext.SetActive(true);
                locktext.SetActive(false);
            }
        }
    }
    public void Selected() {
        PlayerPrefs.SetString("nowLevel",gameObject.name);
        SceneManager.LoadScene(2);
    }
}
