﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace Assets.Scripts {
    struct RollStruct {
        public Vector3 point;
        public Vector3 axis;
        public int b_State;
    }
}
