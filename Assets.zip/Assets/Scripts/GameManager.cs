﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class GameManager : MonoBehaviour
{
    public int step=0;//剩余步数
    public int goalState=0;//
    private List<BoxCollider> targets;
    private GameObject resultCanvas;
    private GameObject result;
    private GameObject retryButton;
    private GameObject nextButton;
    private GameObject manualButton;
    private GameObject panelButton;
    private GameObject stepText;


    private void Awake() {
        GameObject[] objs = GameObject.FindGameObjectsWithTag("target");
        targets = new List<BoxCollider>();
        foreach (GameObject obj in objs) {
            targets.Add(obj.GetComponent<BoxCollider>());
        }
        resultCanvas = GameObject.FindGameObjectWithTag("settlement");
        result = GameObject.FindGameObjectWithTag("result");
        nextButton = GameObject.FindGameObjectWithTag("nextButton");
        retryButton = GameObject.FindGameObjectWithTag("retryButton");
        manualButton = GameObject.FindGameObjectWithTag("manualButton");
        panelButton = GameObject.FindGameObjectWithTag("panelButton");
        stepText = GameObject.Find("stepText");
        nextButton.GetComponent<Button>().onClick.AddListener(nextLevel);
        retryButton.GetComponent<Button>().onClick.AddListener(reTry);
        manualButton.GetComponent<Button>().onClick.AddListener(manual);
        panelButton.GetComponent<Button>().onClick.AddListener(panel);
    }
    private void Start() { 
        resultCanvas.SetActive(false);
        stepText.GetComponent<Text>().text = ("Step:" + step);
    }
    private void receiveMsg(int blockState) {
        step--;
        stepText.GetComponent<Text>().text = ("Step:" + step);
        gameRule(blockState);
    }

    private void gameRule(int blockState) {

        bool isWin = true;

        foreach (BoxCollider collider in targets) {
            collider.enabled = false;
            if(!Physics.Linecast(collider.transform.position, new Vector3(collider.transform.position.x, collider.transform.position.y + 0.5f, collider.transform.position.z))) {
                isWin = false;
            }
            collider.enabled = true;
        }


        if (isWin&&blockState==goalState) {
            resultCanvas.SetActive(true);
            result.GetComponent<Text>().text = "WIN";
            nextButton.GetComponent<Text>().text = "Next";
            retryButton.SetActive(false);
            saveData();
            Debug.Log("WIN");
        }else if (step == 0) {
            resultCanvas.SetActive(true);
            result.GetComponent<Text>().text = "LOSE";
            retryButton.GetComponent<Text>().text = "Retry";
            nextButton.SetActive(false);
            Debug.Log("LOSE");
        }
    }


    public void saveData() {
        string nowLevel = PlayerPrefs.GetString("nowLevel");
        PlayerPrefs.SetInt("level"+ nowLevel, 1);
    }

    public void manual() {
        SceneManager.LoadScene(1);
    }
    public void panel() {
        resultCanvas.SetActive(true);
        retryButton.GetComponent<Text>().text = "Retry";
        nextButton.SetActive(false);
    }

    public void reTry() {
        Time.timeScale = 1;
        SceneManager.LoadScene(2);
    }

    public void nextLevel() {
        Time.timeScale = 1;
        int newLevel= int.Parse(PlayerPrefs.GetString("nowLevel"))+1 ;
        if (newLevel<7) {
            PlayerPrefs.SetString("nowLevel", newLevel.ToString());
            SceneManager.LoadScene(2);
        }

    }

}
