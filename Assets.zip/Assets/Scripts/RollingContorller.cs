﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Assets.Scripts;

public class RollingContorller : MonoBehaviour
{
    private Vector3 point;
    private Vector3 axis;
    private bool isRolling = false;
    private bool rollingFinished = false;
    private int angle = 0;
    GameObject gameManager;
    int b_State;
    public AudioClip moveSound;
    private AudioSource audioSource;

    private void Start() {
        gameManager = GameObject.Find("GameManager");
        audioSource = transform.GetComponent<AudioSource>();
        audioSource.clip = moveSound;
    }
    private void Update() {
        if (isRolling ) {
            if (angle < 15) {
                transform.RotateAround(point,axis,6);
                angle++;
            } else {
                rollingFinished = true;
                isRolling = false;
                angle = 0;
            }
        }
        if (rollingFinished) {
            gameManager.SendMessage("receiveMsg", b_State);
            rollingFinished = false;
        }
    }

    private void receiveMsg(RollStruct message) {
        if (!isRolling) {
            this.point = message.point;
            this.axis = message.axis;
            this.b_State = message.b_State;
            isRolling = true;
            audioSource.Play();
        }

    }

}
